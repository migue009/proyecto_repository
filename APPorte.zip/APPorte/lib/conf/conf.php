<?php
$host /*puede ser server*/= "localhost"; /*servidor*/
$user = "postgres";/*Usuario*/
$pass = "12345";/*contrasena*/
$database = "APPorte";/*BaseDeDatos*/
$port = "5433";/*Puerto*/
//hola este es el de apache
?>
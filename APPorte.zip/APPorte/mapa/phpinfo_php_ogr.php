<?php
  dl("php_ogr.dll");
  phpinfo();
?>

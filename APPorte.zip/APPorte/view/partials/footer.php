<div class="container footer--flex">
    <div class="footer-start">
      <p>2024 ©copyright - APPorte - <a href="APPorte.com" target="_blank"
          rel="noopener noreferrer">APPorte.com </a></p>
    </div>
    
</div>
  <script src = "js/query.js"></script>
  <script src = "js/global.js"></script>
</html>
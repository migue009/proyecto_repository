<div class="container card">
    <div class="mt-2">
        <h3 class="display-4 text-center main-title">Crear Solicitud</h3>
        <?php include_once 'mapa.php'; ?>
    </div>
</div>

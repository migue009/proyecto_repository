<?php
//TODAS LAS RUTAS ARRANCAN DESDE INDEX
    include_once '../model/MasterModel.php';

    class UsuariosModel extends MasterModel{
        
    }
?>